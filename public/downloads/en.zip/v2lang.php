<?php

$lang = [
  'invalid_data' => 'Invalid value'
];

return checkLang($lang);